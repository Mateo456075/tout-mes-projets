<?php
//hsd_panier
session_start
//connexion à la base de doné
-mysqli_connect("localhost", "root", "", "hsd_shop");
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Panier</title>
        <link rel="stylesheet" href="hds.css">
    </head>
    <body class="panier">
        <a href="index.html" class="link">Retour</a>
       <section>
        <table>
            <tr>
                <th></th>
                <th>NOM</th>
                <th>PRIX</th>
                <th>QUANTITE</th>
                <th>Action</th>
            </tr>
            <?php
            $total=0;
            $ids=array_keys($_SESSION['panier']);
            if(empty($ids)){
                echo "votre panier est vide";
            }else {
                $products=mysqli_query($con, "SELECT * FROM indes.html");
            }?>
        </table>
       </section> 
    </body>
</html>