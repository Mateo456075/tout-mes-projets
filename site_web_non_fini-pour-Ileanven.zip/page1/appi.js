let btn = document.getElementById('btn');

btn.addEventListener('click', (e) => {
    e.preventDefault;
    let search = document.getElementById('search');
    let searchWidth = search.offsetWidth;

    if (searchWidth === 0) {
        btn.style.transform = 'rotateZ(90deg)';
        search.style.width = '100%';
        setTimeout(() => {
            search.style.height = '40px';
            search.style.padding = '10px 20px 10px 70px';
        }, 500)
       
    } else if (searchWidth === 350) {
        btn.style.transform = 'rotateZ(0deg)';
        search.style.height = '0';
        search.style.padding = '0';
        setTimeout(() => {
            search.style.width = '0%';
        }, 500)
    }
    console.log(searchWidth);
})

let tabs = document.querySelectorAll('.tab-link:not(.desactive)');

tabs.forEach(tab => {
    tab.addEventListener("click", () => {
        unSelectAll();
        tab.classList.add('active');
        let ref = tab.getAttribute('data-ref');
        document.querySelectorAll('.tab-body[data-id="${ref}"]').classList.add()
    })
})