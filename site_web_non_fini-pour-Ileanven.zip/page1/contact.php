
<?php 
if (isset($_POST["message"])){
    $message = "ce message vous a été envoyé via la page contact du site ileavent Nom : " . $_POST["nom"] . "
    Nom de l'entreprise : " . $_POST["nom de lentreprise"] . "
    Email : " . $_POST["email"] . "
    Message : " . $_POST["message"] . "
    Téléphone : " . $_POST["numéro"];

    $retour = mail("contact@ileaven.fr", $_POST["sujet"], $_POST["sujet"] , $message, "from:contact@exemplesite.fr" . "\r\n" . "reply-to:" . $_POST["email"] , $_POST["numéro"] );
    if ($retour){
        echo "<p> L'email a bien été envoyé.</p>";
    }
} ?>

