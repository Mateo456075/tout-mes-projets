<?php

$con = mysqli_connect("localhost","root","","tutorial") or die("Couldn't connect");

?>